<%@page import="com.sunilos.p4.util.MessageSource"%>
<%@page import="com.sunilos.p4.ctl.MyProfileCtl"%>
<%@page import="com.sunilos.p4.ctl.ORSView"%>
<%@page import="com.sunilos.p4.util.HTMLUtility"%>
<%@page import="java.util.HashMap"%>
<%@page import="com.sunilos.p4.util.DataUtility"%>
<%@page import="com.sunilos.p4.util.ServletUtility"%>

<jsp:useBean id="bean" class="com.sunilos.p4.bean.UserBean"
	scope="request"></jsp:useBean>

<%
MessageSource ms = MessageSource.getInstance();
String _suc = ServletUtility.getSuccessMessage(request);
String _err = ServletUtility.getErrorMessage(request);
HashMap genderMap = new HashMap();
genderMap.put("M", ms.get("male.val"));
genderMap.put("F", ms.get("female.val"));
%>

<div class="container py-4" style="max-width: 660px;">
	<div class="card border-0 shadow-sm rounded-4 overflow-hidden">

		<div class="card-header text-white border-0 py-3 px-4"
			style="background: linear-gradient(135deg, #0d2137 0%, #1565c0 100%);">
			<h5 class="mb-0 fw-bold">
				<i class="bi bi-person-circle me-2"></i>
				<%=ms.get("my.profile")%>
			</h5>
		</div>

		<div class="card-body px-4 py-4">

			<%
			if (_suc != null && !_suc.isEmpty()) {
			%>
			<div class="alert alert-success alert-dismissible py-2">
				<i class="bi bi-check-circle-fill me-2"></i><%=_suc%>
				<button type="button" class="btn-close" data-bs-dismiss="alert"
					aria-label="Close"></button>
			</div>
			<%
			}
			%>
			<%
			if (_err != null && !_err.isEmpty()) {
			%>
			<div class="alert alert-danger alert-dismissible py-2">
				<i class="bi bi-exclamation-triangle-fill me-2"></i><%=_err%>
				<button type="button" class="btn-close" data-bs-dismiss="alert"
					aria-label="Close"></button>
			</div>
			<%
			}
			%>

			<%
			if (bean.getId() > 0) {
			%>
			<div class="d-flex align-items-center gap-3 mb-4">
				<img src="<%=ORSView.UPLOAD_PHOTO_CTL%>?id=<%=bean.getId()%>"
					onerror="this.style.display='none';" alt="User Photo"
					class="rounded-circle border" width="80" height="80"
					style="object-fit: cover;">
				<form action="<%=ORSView.UPLOAD_PHOTO_CTL%>" method="POST"
					enctype="multipart/form-data"
					class="d-flex align-items-center gap-2">
					<input type="hidden" name="view"
						value="<%=ORSView.MY_PROFILE_VIEW%>"><input type="hidden"
						name="id" value="<%=bean.getId()%>"> <input type="file"
						name="photo" class="form-control form-control-sm" accept="image/*">
					<button type="submit"
						class="btn btn-sm btn-outline-primary text-nowrap">
						<i class="bi bi-upload me-1"></i>
						<%=ms.get("button.upload")%>
					</button>
				</form>
			</div>
			<%
			}
			%>

			<form name="profileForm" action="<%=ORSView.MY_PROFILE_CTL%>"
				method="POST">
				<input type="hidden" name="id" value="<%=bean.getId()%>"> <input
					type="hidden" name="createdBy" value="<%=bean.getCreatedBy()%>">
				<input type="hidden" name="modifiedBy"
					value="<%=bean.getModifiedBy()%>"> <input type="hidden"
					name="createdDatetime"
					value="<%=DataUtility.getTimestamp(bean.getCreatedDatetime())%>">
				<input type="hidden" name="modifiedDatetime"
					value="<%=DataUtility.getTimestamp(bean.getModifiedDatetime())%>">


				<input type="hidden" name="password"
					value="<%=DataUtility.getStringData(bean.getPassword())%>">
				<input type="hidden" name="roleId" value="<%=bean.getRoleId()%>">

				<div class="mb-3">
					<label class="form-label fw-semibold"><%=ms.get("login.userid")%></label>
					<input type="text" name="login" class="form-control bg-light"
						readonly value="<%=DataUtility.getStringData(bean.getLogin())%>">
				</div>

				<div class="row g-3 mb-3">
					<div class="col-md-6">
						<label class="form-label fw-semibold"><%=ms.get("first.name")%>
							<span class="text-danger">*</span></label> <input type="text"
							name="firstName" class="form-control"
							value="<%=DataUtility.getStringData(bean.getFirstName())%>">
						<div class="text-danger small mt-1"><%=ServletUtility.getErrorMessage("firstName", request)%></div>
					</div>
					<div class="col-md-6">
						<label class="form-label fw-semibold"><%=ms.get("last.name")%><span
							class="text-danger">*</span></label> <input type="text" name="lastName"
							class="form-control"
							value="<%=DataUtility.getStringData(bean.getLastName())%>">
						<div class="text-danger small mt-1"><%=ServletUtility.getErrorMessage("lastName", request)%></div>
					</div>
				</div>

				<div class="row g-3 mb-3">
					<div class="col-md-6">
						<label class="form-label fw-semibold"><%=ms.get("register.gender")%></label>
						<%=HTMLUtility.getList("gender", bean.getGender(), genderMap)%>
					</div>
					<div class="col-md-6">
						<label class="form-label fw-semibold"><%=ms.get("mobile.title")%><span
							class="text-danger">*</span></label> <input type="text" name="mobileNo"
							class="form-control"
							value="<%=DataUtility.getStringData(bean.getMobileNo())%>">
						<div class="text-danger small mt-1"><%=ServletUtility.getErrorMessage("mobileNo", request)%></div>
					</div>
				</div>

				<div class="mb-4">
					<label class="form-label fw-semibold"><%=ms.get("register.dob")%></label>
					<div class="input-group">
						<input type="text" name="dob" id="udate" class="form-control"
							readonly value="<%=DataUtility.getDateString(bean.getDob())%>">
						<a class="btn btn-outline-secondary"> <img
							src="../img/cal.jpg" width="16" height="15" alt="Calendar">
						</a>
					</div>
					<div class="text-danger small mt-1"><%=ServletUtility.getErrorMessage("dob", request)%></div>
				</div>

				<div class="d-flex gap-2 pt-2 border-top">
					<button type="submit" name="operation"
						value="<%=MyProfileCtl.OP_SAVE%>" class="btn btn-primary">
						<i class="bi bi-save me-1"></i>
						<%=ms.get("button.save")%>
					</button>
					<button type="submit" name="operation"
						value="<%=MyProfileCtl.OP_CHANGE_MY_PASSWORD%>"
						class="btn btn-outline-warning">
						<i class="bi bi-key me-1"></i>
						<%=ms.get("change.password")%>
					</button>
				</div>
			</form>
		</div>
	</div>
</div>
